package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DeleteQuestion extends AppCompatActivity {
    QuizDBhelper db;
    EditText e;
    int n;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_question);
        db=new QuizDBhelper(DeleteQuestion.this);
        e=(EditText)findViewById(R.id.et);
        Button b=(Button)findViewById(R.id.bt);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n=Integer.parseInt(e.getText().toString());
                db.deletequizquestion(n);
            }
        });

    }
}
