package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstPage extends AppCompatActivity {
EditText un,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_page);
        Button b1=(Button)findViewById(R.id.button);
        Button b2=(Button)findViewById(R.id.button2);
        un=(EditText) findViewById(R.id.editText6);
        pwd=(EditText) findViewById(R.id.editText7);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String u=un.getText().toString() ;
                //String p=pwd.getText().toString() ;
                if (un.getText().toString().trim().length() == 0 ||pwd.getText().toString().trim().length() == 0)
                {
                    Toast.makeText(FirstPage.this,"Error,Please enter all values!",Toast.LENGTH_SHORT).show();
                }
                if(un.getText().toString().equals("student") && pwd.getText().toString().equals("student")) {
                    Intent intent = new Intent(FirstPage.this, StudentOptionPage.class);
                    startActivity(intent);
                    clearText();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String u = un.getText().toString();
                String p = pwd.getText().toString();
                if (un.getText().toString().trim().length() == 0 ||pwd.getText().toString().trim().length() == 0)
                {
                    Toast.makeText(FirstPage.this,"Error,Please enter all values!",Toast.LENGTH_SHORT).show();
                }
                if (u.equals( "teacher") && p.equals("teacher")) {
                    Intent intent = new Intent(FirstPage.this, TeacherOptionPage.class);
                    startActivity(intent);
                    clearText();
                }
            }
        });
    }
    public void clearText()
    {
        un.setText("");
        pwd.setText("");
    }
}