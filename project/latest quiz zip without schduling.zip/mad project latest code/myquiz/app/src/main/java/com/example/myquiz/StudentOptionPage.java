package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
        import android.widget.Button;

public class StudentOptionPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.option_for_student);

        Button b1=(Button)findViewById(R.id.button);
        Button logout=(Button)findViewById(R.id.logout);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(StudentOptionPage.this, StartQuizPage.class);
                startActivity(i1);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(StudentOptionPage.this,FirstPage.class);
                startActivity(intent);
            }
        });

    }
}