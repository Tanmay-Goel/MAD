/*
package com.example.myquiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.myquiz.QuizContract.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class QuizDBhelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME="MyQuiz.db";
    private static final int DATABASE_VERSION=2;
    private  SQLiteDatabase db;

    public QuizDBhelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db=db;
        final String SQL_CREATE_QUESTIONS_TABLE="CREATE TABLE "+
                QuestionsTable.TABLE_NAME + " ( "+
                QuestionsTable._ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER + " INTEGER " +
                ")";
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    private void fillQuestionsTable(){
        Question q1=new Question("Who invented python programming language?","Guido van Rossum","Charles Babbage","James Gosling",1                );
        addQuestion(q1);
        Question q2=new Question("Which is the largest river in the world?","Amazon","Nile","Ganga",2);
        addQuestion(q2);
        Question q3=new Question("How many islands are there in the group of lakshadweep?","34","35","36",3);
        addQuestion(q3);
        Question q4=new Question("The Gulf of Mannar is situated on the banks of which river?","Ganga","Yamuna","Brahmaputra",3);
        addQuestion(q4);
        Question q5=new Question("How many main() functions can we have in a c program?","only 1","more than 1","no need of main() function",1);
        addQuestion(q5);
        Question q6=new Question("2+2*2/2=?","6","4","8",2);
        addQuestion(q6);
        Question q7=new Question("9%2*0?","4.5","0","1",2);
        addQuestion(q7);
        Question q8=new Question("_________ method cannot be overridden?","private","final","static",3);
        addQuestion(q8);
        Question q9=new Question("If log(1/8) to the base x = -3/2, then x=?","-4","4","1/4",2);
        addQuestion(q9);
        Question q10=new Question("In java arrays are _________.","object reference","object","data type",2);
        addQuestion(q10);
    }
    private  void addQuestion(Question question){
        ContentValues cv=new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION,question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1,question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2,question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3,question.getOption3());
        cv.put(QuestionsTable.COLUMN_ANSWER,question.getAnswer());
        db.insert(QuestionsTable.TABLE_NAME,null,cv);
    }
    public ArrayList<Question> getAllQuestions(){
        ArrayList<Question>questionList =new ArrayList<>();
        db=getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM "+ QuestionsTable.TABLE_NAME,null);

        if(c.moveToFirst()){
            do{
                Question question =new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setAnswer(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER)));
                questionList.add(question);
            }while(c.moveToNext());
        }
        c.close();
        return questionList;
    }
}

 */
package com.example.myquiz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.myquiz.QuizContract.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import static com.example.myquiz.QuizContract.QuestionsTable.*;
import static com.example.myquiz.QuizContract.QuestionsTable.TABLE_NAME;

public class QuizDBhelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyQuiz.db";
    private static final int DATABASE_VERSION = 2;
    private SQLiteDatabase db;
    private static final String TABLE = "STUDENT";
    public static final String COL_1 = "USN";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "EMAIL";
    public static final String COL_4 = "USERNAME";
    public static final String COL_5 = "PASSWORD";
    public static final String COL_6 = "ATTEMPTS";
    public static final String COL_7 = "MARKS";


    public QuizDBhelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                TABLE_NAME + " ( " +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_QUESTION + " TEXT, " +
                COLUMN_OPTION1 + " TEXT, " +
                COLUMN_OPTION2 + " TEXT, " +
                COLUMN_OPTION3 + " TEXT, " +
                COLUMN_ANSWER + " INTEGER " +
                ")";
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();

        final String CREATE_STUDENT_TABLE = "CREATE TABLE " +
                TABLE + "" + "(USN INTEGER PRIMARY KEY AUTOINCREMENT," + " NAME TEXT," +
                "EMAIL TEXT," +
                "USERNAME TEXT," +
                "PASSWORD TEXT," +
                "ATTEMPTS INTEGER," +
                "MARKS INTEGER)";
        db.execSQL(CREATE_STUDENT_TABLE);
        insert_record();


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    private void fillQuestionsTable() {
        Question q1 = new Question("Who invented python programming language?", "Guido van Rossum", "Charles Babbage", "James Gosling", 1);
        addQuestion(q1);
        Question q2 = new Question("Which is the largest river in the world?", "Amazon", "Nile", "Ganga", 2);
        addQuestion(q2);
        Question q3 = new Question("How many islands are there in the group of lakshadweep?", "34", "35", "36", 3);
        addQuestion(q3);
        Question q4 = new Question("The Gulf of Mannar is situated on the banks of which river?", "Ganga", "Yamuna", "Brahmaputra", 3);
        addQuestion(q4);
        Question q5 = new Question("How many main() functions can we have in a c program?", "only 1", "more than 1", "no need of main() function", 1);
        addQuestion(q5);
        Question q6 = new Question("2+2*2/2=?", "6", "4", "8", 2);
        addQuestion(q6);
        Question q7 = new Question("9%2*0?", "4.5", "0", "1", 2);
        addQuestion(q7);
        Question q8 = new Question("_________ method cannot be overridden?", "private", "final", "static", 3);
        addQuestion(q8);
        Question q9 = new Question("If log(1/8) to the base x = -3/2, then x=?", "-4", "4", "1/4", 2);
        addQuestion(q9);
        Question q10 = new Question("In java arrays are _________.", "object reference", "object", "data type", 2);
        addQuestion(q10);
    }

    private void addQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_QUESTION, question.getQuestion());
        cv.put(COLUMN_OPTION1, question.getOption1());
        cv.put(COLUMN_OPTION2, question.getOption2());
        cv.put(COLUMN_OPTION3, question.getOption3());
        cv.put(COLUMN_ANSWER, question.getAnswer());
        db.insert(TABLE_NAME, null, cv);
    }

    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(COLUMN_OPTION3)));
                question.setAnswer(c.getInt(c.getColumnIndex(COLUMN_ANSWER)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close();
        return questionList;
    }

    public void insert_record() {
        String query1 = "INSERT INTO Student VALUES (100,'abc','abc@gmail.com','abc','100',0,0);";
        String query2 = "INSERT INTO Student VALUES (101,'def','def@gmail.com','def','101',0,0);";
        String query3 = "INSERT INTO Student VALUES (102,'xyz','xyz@gmail.com','xyz','102',0,0);";
        db.execSQL(query1);
        db.execSQL(query2);
        db.execSQL(query3);
    }

    public void UpdateRecord(int usn, String name, String mail) {
        db = getReadableDatabase();
        db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM  TABLE  WHERE USN='" + usn + "';", null);
        if (c.getCount() <= 0) {
            String query = "INSERT INTO Student VALUES (usn,name,mail);";
            c.close();
        } else {
            String query = "UPDATE Student SET NAME=" + name + ", EMAIL=" + mail + " WHERE USN=" + usn + " ;";
            c.close();
        }

    }

    public Boolean VerifyStudent(String user, int psw) {
        db = getReadableDatabase();
        String query = "SELECT * FROM   TABLE  WHERE USN ='" + psw + "' AND  NAME = '" + user + "';";
        Cursor c = db.rawQuery(query, null);
        if (c.getCount() >= 0) {
            //intetnt and move to next page -- login successful
            return true;
        } else {
            //invalid login
            return false;
        }

    }

    public void DeleteRecord(int usn) {
        db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE + "WHERE USN =" + usn;
        Cursor c = db.rawQuery(query, null);
        if (c.getCount() >= 0) {
            //intetnt and move to next page -- login successful
            String query2 = "DELETE from " + TABLE + "USN = " + usn;
            db.execSQL(query2);
        } else {
            //invalid login
            //Toast.makeText(QuizDBhelper.this, "Invalid USN", Toast.LENGTH_SHORT).show();
        }

    }

    public void deletequizquestion(int no) {
        db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + "WHERE _ID =" + no;
        Cursor c = db.rawQuery(query, null);
        if (c.getCount() >= 0) {
            //intetnt and move to next page -- login successful
            String query2 = "DELETE from " + TABLE_NAME + "Where _ID = " + no;
            db.execSQL(query2);
        }

        public void ViewStudents() {
            db = getReadableDatabase();
            String query ="SELECT * from " + TABLE;
            Cursor c = db.rawQuery(query, null);
            if (c.getCount() >= 0) {
                StringBuffer buffer=new StringBuffer();

                while(c.moveToNext())
                {
                    buffer.append("USN: "+c.getString(0)+"\n");
                    buffer.append("Name: "+c.getString(1)+"\n");
                    buffer.append("Email: "+c.getString(2)+"\n\n");
                    buffer.append("username: "+c.getString(3)+"\n\n");
                    buffer.append("password: "+c.getString(4)+"\n\n");
                    buffer.append("attempts: "+c.getString(5)+"\n\n");
                    buffer.append("marks: "+c.getString(6)+"\n\n");

                }
            }
        }

        public void ViewQuestions() {
            db = getReadableDatabase();
            String query ="SELECT * from " + TABLE_NAME;
            Cursor c = db.rawQuery(query, null);
            if (c.getCount() >= 0) {
                StringBuffer buffer=new StringBuffer();

                while(c.moveToNext())
                {
                    buffer.append("ID: "+c.getString(0)+"\n");
                    buffer.append("Question: "+c.getString(1)+"\n");
                    buffer.append("Option 1: "+c.getString(2)+"\n\n");
                    buffer.append("Option 2: "+c.getString(3)+"\n\n");
                    buffer.append("Option 3: "+c.getString(4)+"\n\n");
                    buffer.append("Correct Option: "+c.getString(5)+"\n\n");

                }
            }
        }

        public void ViewMarks () {
            db = getReadableDatabase();
           String query= "SELECT ID,NAME, Marks from " + TABLE + " ORDER By USN";
            Cursor c = db.rawQuery(query, null);
            if (c.getCount() >= 0) {
                StringBuffer buffer=new StringBuffer();

                while(c.moveToNext())
                {
                    buffer.append("USN: "+c.getString(0)+"\n");
                    buffer.append("Name: "+c.getString(1)+"\n");
                    buffer.append("Marks: "+c.getString(6)+"\n\n");

                }
            }

        }

    }

}