package com.example.myquiz;
import android.content.Intent;
        import android.os.Bundle;
        import androidx.appcompat.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;


public class TeacherOptionPage extends AppCompatActivity {
    QuizDBhelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.option_for_teacher);
        db=new QuizDBhelper(TeacherOptionPage.this);
        Button schedule_quiz=(Button)findViewById(R.id.schedule_quiz);
        Button add_question=(Button)findViewById(R.id.add_question);
        Button logout=(Button)findViewById(R.id.logout);
        Button add_student=(Button)findViewById(R.id.add_student);
        Button view_student=(Button)findViewById(R.id.view_student);
        Button delete_student=(Button)findViewById(R.id.delete_student);
        Button view_question=(Button)findViewById(R.id.view_question);
        Button view_marks=(Button)findViewById(R.id.view_marks);
        Button delete_question=(Button)findViewById(R.id.delete_question);

       schedule_quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(TeacherOptionPage.this, ConductQuizTeacher.class);
                startActivity(i1);
            }
        });

       add_question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i2=new Intent(TeacherOptionPage.this, AddQuestionTeacher.class);
                startActivity(i2);
            }
        });

       view_question.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

           }
       });

        delete_question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        add_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        view_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });

        delete_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        view_marks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TeacherOptionPage.this,FirstPage.class);
                startActivity(intent);
            }
        });


    }

}